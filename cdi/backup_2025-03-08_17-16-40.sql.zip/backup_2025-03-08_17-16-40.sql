

CREATE TABLE `nav` (
  `id_nav` int NOT NULL AUTO_INCREMENT,
  `nav_titre` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `nav_url` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id_nav`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO nav VALUES ('1', 'Le golf', '#');
INSERT INTO nav VALUES ('2', 'Parcours', '#');
INSERT INTO nav VALUES ('3', 'Compétitions', '#');
INSERT INTO nav VALUES ('4', 'Enseignement', '#');
INSERT INTO nav VALUES ('5', 'Actualités', '#');
INSERT INTO nav VALUES ('6', 'Contact', '#');
INSERT INTO nav VALUES ('7', '|', '#');
INSERT INTO nav VALUES ('8', 'Réserver un départ', '#');


CREATE TABLE `sous_nav` (
  `id_sous_nav` int NOT NULL AUTO_INCREMENT,
  `sn_titre` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `sn_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `id_nav` int NOT NULL,
  PRIMARY KEY (`id_sous_nav`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO sous_nav VALUES ('1', 'Trou  1', '#', '2');
INSERT INTO sous_nav VALUES ('2', 'Trou  2', '#', '2');
INSERT INTO sous_nav VALUES ('3', 'Trou  3', '#', '2');
INSERT INTO sous_nav VALUES ('4', 'Trou  4', '#', '2');
INSERT INTO sous_nav VALUES ('5', 'Trou  5', '#', '2');
INSERT INTO sous_nav VALUES ('6', 'Trou  6', '#', '2');
INSERT INTO sous_nav VALUES ('7', 'Trou  7', '#', '2');
INSERT INTO sous_nav VALUES ('8', 'Trou  8', '#', '2');
INSERT INTO sous_nav VALUES ('9', 'Trou  9', '#', '2');
INSERT INTO sous_nav VALUES ('10', 'Trou 10', '#', '2');
INSERT INTO sous_nav VALUES ('11', 'Trou 11', '#', '2');
INSERT INTO sous_nav VALUES ('12', 'Trou 12', '#', '2');
INSERT INTO sous_nav VALUES ('13', 'Trou 13', '#', '2');
INSERT INTO sous_nav VALUES ('14', 'Trou 14', '#', '2');
INSERT INTO sous_nav VALUES ('15', 'Trou 15', '#', '2');
INSERT INTO sous_nav VALUES ('16', 'Trou 16', '#', '2');
INSERT INTO sous_nav VALUES ('17', 'Trou 17', '#', '2');
INSERT INTO sous_nav VALUES ('18', 'Trou 18', '#', '2');
INSERT INTO sous_nav VALUES ('19', 'Histoire', '#', '3');
INSERT INTO sous_nav VALUES ('20', 'Équipe', '#', '3');
INSERT INTO sous_nav VALUES ('21', 'Contact', '#', '3');
INSERT INTO sous_nav VALUES ('22', 'Histoire', '#', '4');
INSERT INTO sous_nav VALUES ('23', 'Équipe', '#', '4');
INSERT INTO sous_nav VALUES ('24', 'Contact', '#', '4');
INSERT INTO sous_nav VALUES ('25', 'Histoire', '#', '5');
INSERT INTO sous_nav VALUES ('26', 'Équipe', '#', '5');
INSERT INTO sous_nav VALUES ('27', 'Ludovic LOUDIERE', 'http://ludovicloudiere.eu/via', '5');
INSERT INTO sous_nav VALUES ('28', 'Moi', '#', '8');
INSERT INTO sous_nav VALUES ('29', 'Toi', '#', '8');
INSERT INTO sous_nav VALUES ('30', 'Lui', '#', '8');
